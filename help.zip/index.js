const MusicBot = require('./Music/src/SondMix');
module.exports = MusicBot;